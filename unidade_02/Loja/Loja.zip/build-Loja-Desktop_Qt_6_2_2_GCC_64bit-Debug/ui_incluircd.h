/********************************************************************************
** Form generated from reading UI file 'incluircd.ui'
**
** Created by: Qt User Interface Compiler version 6.2.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INCLUIRCD_H
#define UI_INCLUIRCD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_IncluirCD
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_preco;
    QLineEdit *lineEdit_faixas;
    QLabel *label;
    QLineEdit *lineEdit_nome;
    QLabel *label_3;
    QLabel *label_2;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *IncluirCD)
    {
        if (IncluirCD->objectName().isEmpty())
            IncluirCD->setObjectName(QString::fromUtf8("IncluirCD"));
        IncluirCD->resize(300, 200);
        verticalLayout = new QVBoxLayout(IncluirCD);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_4 = new QLabel(IncluirCD);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_4);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(20);
        gridLayout->setVerticalSpacing(30);
        lineEdit_preco = new QLineEdit(IncluirCD);
        lineEdit_preco->setObjectName(QString::fromUtf8("lineEdit_preco"));

        gridLayout->addWidget(lineEdit_preco, 1, 1, 1, 1);

        lineEdit_faixas = new QLineEdit(IncluirCD);
        lineEdit_faixas->setObjectName(QString::fromUtf8("lineEdit_faixas"));

        gridLayout->addWidget(lineEdit_faixas, 2, 1, 1, 1);

        label = new QLabel(IncluirCD);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit_nome = new QLineEdit(IncluirCD);
        lineEdit_nome->setObjectName(QString::fromUtf8("lineEdit_nome"));

        gridLayout->addWidget(lineEdit_nome, 0, 1, 1, 1);

        label_3 = new QLabel(IncluirCD);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        label_2 = new QLabel(IncluirCD);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        buttonBox = new QDialogButtonBox(IncluirCD);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(true);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(IncluirCD);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, IncluirCD, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, IncluirCD, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(IncluirCD);
    } // setupUi

    void retranslateUi(QDialog *IncluirCD)
    {
        IncluirCD->setWindowTitle(QCoreApplication::translate("IncluirCD", "Dialog", nullptr));
        label_4->setText(QCoreApplication::translate("IncluirCD", "Incluir CD", nullptr));
        label->setText(QCoreApplication::translate("IncluirCD", "Nome", nullptr));
        label_3->setText(QCoreApplication::translate("IncluirCD", "N Faixas", nullptr));
        label_2->setText(QCoreApplication::translate("IncluirCD", "Pre\303\247o", nullptr));
    } // retranslateUi

};

namespace Ui {
    class IncluirCD: public Ui_IncluirCD {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INCLUIRCD_H
