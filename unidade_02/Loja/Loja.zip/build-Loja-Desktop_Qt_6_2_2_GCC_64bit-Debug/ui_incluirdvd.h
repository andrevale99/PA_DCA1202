/********************************************************************************
** Form generated from reading UI file 'incluirdvd.ui'
**
** Created by: Qt User Interface Compiler version 6.2.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INCLUIRDVD_H
#define UI_INCLUIRDVD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_IncluirDVD
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_preco;
    QLineEdit *lineEdit_duracao;
    QLabel *label;
    QLineEdit *lineEdit_nome;
    QLabel *label_3;
    QLabel *label_2;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *IncluirDVD)
    {
        if (IncluirDVD->objectName().isEmpty())
            IncluirDVD->setObjectName(QString::fromUtf8("IncluirDVD"));
        IncluirDVD->resize(300, 200);
        verticalLayout = new QVBoxLayout(IncluirDVD);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_4 = new QLabel(IncluirDVD);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_4);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(20);
        gridLayout->setVerticalSpacing(30);
        lineEdit_preco = new QLineEdit(IncluirDVD);
        lineEdit_preco->setObjectName(QString::fromUtf8("lineEdit_preco"));

        gridLayout->addWidget(lineEdit_preco, 1, 1, 1, 1);

        lineEdit_duracao = new QLineEdit(IncluirDVD);
        lineEdit_duracao->setObjectName(QString::fromUtf8("lineEdit_duracao"));

        gridLayout->addWidget(lineEdit_duracao, 2, 1, 1, 1);

        label = new QLabel(IncluirDVD);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit_nome = new QLineEdit(IncluirDVD);
        lineEdit_nome->setObjectName(QString::fromUtf8("lineEdit_nome"));

        gridLayout->addWidget(lineEdit_nome, 0, 1, 1, 1);

        label_3 = new QLabel(IncluirDVD);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        label_2 = new QLabel(IncluirDVD);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        buttonBox = new QDialogButtonBox(IncluirDVD);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(true);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(IncluirDVD);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, IncluirDVD, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, IncluirDVD, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(IncluirDVD);
    } // setupUi

    void retranslateUi(QDialog *IncluirDVD)
    {
        IncluirDVD->setWindowTitle(QCoreApplication::translate("IncluirDVD", "Dialog", nullptr));
        label_4->setText(QCoreApplication::translate("IncluirDVD", "Incluir DVD", nullptr));
        label->setText(QCoreApplication::translate("IncluirDVD", "Nome", nullptr));
        label_3->setText(QCoreApplication::translate("IncluirDVD", "Dura\303\247\303\243o", nullptr));
        label_2->setText(QCoreApplication::translate("IncluirDVD", "Pre\303\247o", nullptr));
    } // retranslateUi

};

namespace Ui {
    class IncluirDVD: public Ui_IncluirDVD {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INCLUIRDVD_H
