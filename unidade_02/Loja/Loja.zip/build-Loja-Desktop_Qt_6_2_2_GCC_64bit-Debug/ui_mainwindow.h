/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionLer;
    QAction *actionSalvar;
    QAction *actionSair;
    QAction *actionIncluir_Livro;
    QAction *actionIncluir_CD;
    QAction *actionIncluir_DVD;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_livros;
    QLabel *label_cds;
    QLabel *label_dvds;
    QHBoxLayout *horizontalLayout;
    QTableWidget *table_livros;
    QTableWidget *table_cds;
    QTableWidget *table_dvds;
    QMenuBar *menubar;
    QMenu *menuArquivo;
    QMenu *menuItem;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(1000, 600);
        actionLer = new QAction(MainWindow);
        actionLer->setObjectName(QString::fromUtf8("actionLer"));
        actionSalvar = new QAction(MainWindow);
        actionSalvar->setObjectName(QString::fromUtf8("actionSalvar"));
        actionSair = new QAction(MainWindow);
        actionSair->setObjectName(QString::fromUtf8("actionSair"));
        actionIncluir_Livro = new QAction(MainWindow);
        actionIncluir_Livro->setObjectName(QString::fromUtf8("actionIncluir_Livro"));
        actionIncluir_CD = new QAction(MainWindow);
        actionIncluir_CD->setObjectName(QString::fromUtf8("actionIncluir_CD"));
        actionIncluir_DVD = new QAction(MainWindow);
        actionIncluir_DVD->setObjectName(QString::fromUtf8("actionIncluir_DVD"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_livros = new QLabel(centralwidget);
        label_livros->setObjectName(QString::fromUtf8("label_livros"));
        label_livros->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_livros);

        label_cds = new QLabel(centralwidget);
        label_cds->setObjectName(QString::fromUtf8("label_cds"));
        label_cds->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_cds);

        label_dvds = new QLabel(centralwidget);
        label_dvds->setObjectName(QString::fromUtf8("label_dvds"));
        label_dvds->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_dvds);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        table_livros = new QTableWidget(centralwidget);
        if (table_livros->columnCount() < 3)
            table_livros->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        table_livros->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        table_livros->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        table_livros->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        table_livros->setObjectName(QString::fromUtf8("table_livros"));
        table_livros->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        table_livros->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        table_livros->setTabKeyNavigation(false);
        table_livros->setSelectionMode(QAbstractItemView::SingleSelection);
        table_livros->setSelectionBehavior(QAbstractItemView::SelectRows);
        table_livros->verticalHeader()->setVisible(false);

        horizontalLayout->addWidget(table_livros);

        table_cds = new QTableWidget(centralwidget);
        if (table_cds->columnCount() < 3)
            table_cds->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        table_cds->setHorizontalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        table_cds->setHorizontalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        table_cds->setHorizontalHeaderItem(2, __qtablewidgetitem5);
        table_cds->setObjectName(QString::fromUtf8("table_cds"));
        table_cds->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        table_cds->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        table_cds->setTabKeyNavigation(false);
        table_cds->setSelectionMode(QAbstractItemView::SingleSelection);
        table_cds->setSelectionBehavior(QAbstractItemView::SelectRows);
        table_cds->verticalHeader()->setVisible(false);

        horizontalLayout->addWidget(table_cds);

        table_dvds = new QTableWidget(centralwidget);
        if (table_dvds->columnCount() < 3)
            table_dvds->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        table_dvds->setHorizontalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        table_dvds->setHorizontalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        table_dvds->setHorizontalHeaderItem(2, __qtablewidgetitem8);
        table_dvds->setObjectName(QString::fromUtf8("table_dvds"));
        table_dvds->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        table_dvds->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        table_dvds->setTabKeyNavigation(false);
        table_dvds->setSelectionMode(QAbstractItemView::SingleSelection);
        table_dvds->setSelectionBehavior(QAbstractItemView::SelectRows);
        table_dvds->verticalHeader()->setVisible(false);

        horizontalLayout->addWidget(table_dvds);


        verticalLayout->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1000, 20));
        menuArquivo = new QMenu(menubar);
        menuArquivo->setObjectName(QString::fromUtf8("menuArquivo"));
        menuItem = new QMenu(menubar);
        menuItem->setObjectName(QString::fromUtf8("menuItem"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuArquivo->menuAction());
        menubar->addAction(menuItem->menuAction());
        menuArquivo->addAction(actionLer);
        menuArquivo->addAction(actionSalvar);
        menuArquivo->addSeparator();
        menuArquivo->addAction(actionSair);
        menuItem->addAction(actionIncluir_Livro);
        menuItem->addAction(actionIncluir_CD);
        menuItem->addAction(actionIncluir_DVD);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Estoque em Loja", nullptr));
        actionLer->setText(QCoreApplication::translate("MainWindow", "Ler", nullptr));
        actionSalvar->setText(QCoreApplication::translate("MainWindow", "Salvar", nullptr));
        actionSair->setText(QCoreApplication::translate("MainWindow", "Sair", nullptr));
        actionIncluir_Livro->setText(QCoreApplication::translate("MainWindow", "Incluir Livro", nullptr));
        actionIncluir_CD->setText(QCoreApplication::translate("MainWindow", "Incluir CD", nullptr));
        actionIncluir_DVD->setText(QCoreApplication::translate("MainWindow", "Incluir DVD", nullptr));
        label_livros->setText(QCoreApplication::translate("MainWindow", "LIVROS", nullptr));
        label_cds->setText(QCoreApplication::translate("MainWindow", "CDS", nullptr));
        label_dvds->setText(QCoreApplication::translate("MainWindow", "DVDS", nullptr));
        QTableWidgetItem *___qtablewidgetitem = table_livros->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "NOME", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = table_livros->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "PRE\303\207O", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = table_livros->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "AUTOR", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = table_cds->horizontalHeaderItem(0);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "NOME", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = table_cds->horizontalHeaderItem(1);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "PRE\303\207O", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = table_cds->horizontalHeaderItem(2);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "FAIXAS", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = table_dvds->horizontalHeaderItem(0);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "NOME", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = table_dvds->horizontalHeaderItem(1);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "PRE\303\207O", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = table_dvds->horizontalHeaderItem(2);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("MainWindow", "DURA\303\207\303\203O", nullptr));
        menuArquivo->setTitle(QCoreApplication::translate("MainWindow", "Arquivo", nullptr));
        menuItem->setTitle(QCoreApplication::translate("MainWindow", "Item", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
