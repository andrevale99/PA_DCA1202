/********************************************************************************
** Form generated from reading UI file 'incluirlivro.ui'
**
** Created by: Qt User Interface Compiler version 6.2.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INCLUIRLIVRO_H
#define UI_INCLUIRLIVRO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_IncluirLivro
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_preco;
    QLineEdit *lineEdit_autor;
    QLabel *label;
    QLineEdit *lineEdit_nome;
    QLabel *label_3;
    QLabel *label_2;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *IncluirLivro)
    {
        if (IncluirLivro->objectName().isEmpty())
            IncluirLivro->setObjectName(QString::fromUtf8("IncluirLivro"));
        IncluirLivro->resize(300, 200);
        verticalLayout = new QVBoxLayout(IncluirLivro);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_4 = new QLabel(IncluirLivro);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_4);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(20);
        gridLayout->setVerticalSpacing(30);
        lineEdit_preco = new QLineEdit(IncluirLivro);
        lineEdit_preco->setObjectName(QString::fromUtf8("lineEdit_preco"));

        gridLayout->addWidget(lineEdit_preco, 1, 1, 1, 1);

        lineEdit_autor = new QLineEdit(IncluirLivro);
        lineEdit_autor->setObjectName(QString::fromUtf8("lineEdit_autor"));

        gridLayout->addWidget(lineEdit_autor, 2, 1, 1, 1);

        label = new QLabel(IncluirLivro);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit_nome = new QLineEdit(IncluirLivro);
        lineEdit_nome->setObjectName(QString::fromUtf8("lineEdit_nome"));

        gridLayout->addWidget(lineEdit_nome, 0, 1, 1, 1);

        label_3 = new QLabel(IncluirLivro);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        label_2 = new QLabel(IncluirLivro);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        buttonBox = new QDialogButtonBox(IncluirLivro);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(true);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(IncluirLivro);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, IncluirLivro, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, IncluirLivro, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(IncluirLivro);
    } // setupUi

    void retranslateUi(QDialog *IncluirLivro)
    {
        IncluirLivro->setWindowTitle(QCoreApplication::translate("IncluirLivro", "Dialog", nullptr));
        label_4->setText(QCoreApplication::translate("IncluirLivro", "Incluir Livro", nullptr));
        label->setText(QCoreApplication::translate("IncluirLivro", "Nome", nullptr));
        label_3->setText(QCoreApplication::translate("IncluirLivro", "Autor", nullptr));
        label_2->setText(QCoreApplication::translate("IncluirLivro", "Pre\303\247o", nullptr));
    } // retranslateUi

};

namespace Ui {
    class IncluirLivro: public Ui_IncluirLivro {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INCLUIRLIVRO_H
