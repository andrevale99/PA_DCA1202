/****************************************************************************
** Meta object code from reading C++ file 'whatsprog_main.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "whatsprog_main.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'whatsprog_main.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_WhatsProgMain_t {
    const uint offsetsAndSize[60];
    char stringdata0[563];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_WhatsProgMain_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_WhatsProgMain_t qt_meta_stringdata_WhatsProgMain = {
    {
QT_MOC_LITERAL(0, 13), // "WhatsProgMain"
QT_MOC_LITERAL(14, 9), // "signLogin"
QT_MOC_LITERAL(24, 0), // ""
QT_MOC_LITERAL(25, 11), // "NovoUsuario"
QT_MOC_LITERAL(37, 20), // "signShowNovaConversa"
QT_MOC_LITERAL(58, 13), // "lancar_thread"
QT_MOC_LITERAL(72, 15), // "terminar_thread"
QT_MOC_LITERAL(88, 16), // "listar_Mensagens"
QT_MOC_LITERAL(105, 12), // "IterConversa"
QT_MOC_LITERAL(118, 3), // "itr"
QT_MOC_LITERAL(122, 22), // "interface_Desconectada"
QT_MOC_LITERAL(145, 16), // "listar_Conversas"
QT_MOC_LITERAL(162, 22), // "slot_CriaLogar_Usuario"
QT_MOC_LITERAL(185, 2), // "ip"
QT_MOC_LITERAL(188, 7), // "usuario"
QT_MOC_LITERAL(196, 5), // "senha"
QT_MOC_LITERAL(202, 7), // "eh_novo"
QT_MOC_LITERAL(210, 17), // "slotNova_Conversa"
QT_MOC_LITERAL(228, 31), // "on_actionNovo_usuario_triggered"
QT_MOC_LITERAL(260, 36), // "on_actionUsuario_existente_tr..."
QT_MOC_LITERAL(297, 30), // "on_actionDesconectar_triggered"
QT_MOC_LITERAL(328, 23), // "on_actionSair_triggered"
QT_MOC_LITERAL(352, 27), // "on_tableConversas_activated"
QT_MOC_LITERAL(380, 11), // "QModelIndex"
QT_MOC_LITERAL(392, 5), // "index"
QT_MOC_LITERAL(398, 25), // "on_tableConversas_clicked"
QT_MOC_LITERAL(424, 33), // "on_lineEditMensagem_returnPre..."
QT_MOC_LITERAL(458, 32), // "on_actionNova_conversa_triggered"
QT_MOC_LITERAL(491, 35), // "on_actionRemover_conversa_tri..."
QT_MOC_LITERAL(527, 35) // "on_actionApagar_mensagens_tri..."

    },
    "WhatsProgMain\0signLogin\0\0NovoUsuario\0"
    "signShowNovaConversa\0lancar_thread\0"
    "terminar_thread\0listar_Mensagens\0"
    "IterConversa\0itr\0interface_Desconectada\0"
    "listar_Conversas\0slot_CriaLogar_Usuario\0"
    "ip\0usuario\0senha\0eh_novo\0slotNova_Conversa\0"
    "on_actionNovo_usuario_triggered\0"
    "on_actionUsuario_existente_triggered\0"
    "on_actionDesconectar_triggered\0"
    "on_actionSair_triggered\0"
    "on_tableConversas_activated\0QModelIndex\0"
    "index\0on_tableConversas_clicked\0"
    "on_lineEditMensagem_returnPressed\0"
    "on_actionNova_conversa_triggered\0"
    "on_actionRemover_conversa_triggered\0"
    "on_actionApagar_mensagens_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WhatsProgMain[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  128,    2, 0x06,    1 /* Public */,
       4,    0,  131,    2, 0x06,    3 /* Public */,
       5,    0,  132,    2, 0x06,    4 /* Public */,
       6,    0,  133,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       7,    1,  134,    2, 0x08,    6 /* Private */,
      10,    0,  137,    2, 0x08,    8 /* Private */,
      11,    0,  138,    2, 0x08,    9 /* Private */,
      12,    4,  139,    2, 0x08,   10 /* Private */,
      17,    1,  148,    2, 0x08,   15 /* Private */,
      18,    0,  151,    2, 0x08,   17 /* Private */,
      19,    0,  152,    2, 0x08,   18 /* Private */,
      20,    0,  153,    2, 0x08,   19 /* Private */,
      21,    0,  154,    2, 0x08,   20 /* Private */,
      22,    1,  155,    2, 0x08,   21 /* Private */,
      25,    1,  158,    2, 0x08,   23 /* Private */,
      26,    0,  161,    2, 0x08,   25 /* Private */,
      27,    0,  162,    2, 0x08,   26 /* Private */,
      28,    0,  163,    2, 0x08,   27 /* Private */,
      29,    0,  164,    2, 0x08,   28 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   13,   14,   15,   16,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void WhatsProgMain::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<WhatsProgMain *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signLogin((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->signShowNovaConversa(); break;
        case 2: _t->lancar_thread(); break;
        case 3: _t->terminar_thread(); break;
        case 4: _t->listar_Mensagens((*reinterpret_cast< IterConversa(*)>(_a[1]))); break;
        case 5: _t->interface_Desconectada(); break;
        case 6: _t->listar_Conversas(); break;
        case 7: _t->slot_CriaLogar_Usuario((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 8: _t->slotNova_Conversa((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->on_actionNovo_usuario_triggered(); break;
        case 10: _t->on_actionUsuario_existente_triggered(); break;
        case 11: _t->on_actionDesconectar_triggered(); break;
        case 12: _t->on_actionSair_triggered(); break;
        case 13: _t->on_tableConversas_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 14: _t->on_tableConversas_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 15: _t->on_lineEditMensagem_returnPressed(); break;
        case 16: _t->on_actionNova_conversa_triggered(); break;
        case 17: _t->on_actionRemover_conversa_triggered(); break;
        case 18: _t->on_actionApagar_mensagens_triggered(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (WhatsProgMain::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WhatsProgMain::signLogin)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (WhatsProgMain::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WhatsProgMain::signShowNovaConversa)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (WhatsProgMain::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WhatsProgMain::lancar_thread)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (WhatsProgMain::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WhatsProgMain::terminar_thread)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject WhatsProgMain::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_WhatsProgMain.offsetsAndSize,
    qt_meta_data_WhatsProgMain,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_WhatsProgMain_t
, QtPrivate::TypeAndForceComplete<WhatsProgMain, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<IterConversa, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *WhatsProgMain::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WhatsProgMain::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_WhatsProgMain.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int WhatsProgMain::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void WhatsProgMain::signLogin(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void WhatsProgMain::signShowNovaConversa()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void WhatsProgMain::lancar_thread()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void WhatsProgMain::terminar_thread()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
